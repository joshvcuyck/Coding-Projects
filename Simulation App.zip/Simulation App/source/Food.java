import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import javax.swing.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Food extends PApplet {

//Food object class

  static boolean inBoundry;

class Foods{
  
  PVector pos, vel;
  float r;
  float timeBeen = 0;
  float timeSaved = 0;
  float timeTillAdult = 2000; //Every 3 seconds food will sprout a new food
  boolean canSprout = false;
  boolean hasSprouted = false;
  float foodTimeCycle = 500;
  float tempTime;

  
  //Constructor
  Foods(float _x, float _y, float _r){
    pos = new PVector(_x, _y);
    vel = new PVector(0,0);
    r = _r;
    timeBeen = millis();
    timeSaved = millis();
    tempTime = millis();

  }

    public void show() {
      
        stroke(255);
        strokeWeight(1);
        fill(255);
        ellipse(pos.x, pos.y, r*2, r*2);
      
    }
    
    public float x(){
      return pos.x;
    }
    
    public float y(){
      return pos.y;
    }
    
    public void update(){
      
      timeBeen = millis();
      
      if(timeBeen - timeSaved >= timeTillAdult ){
      
          canSprout = true;
        
      }
      
      if(hasSprouted){
        if(timeBeen - tempTime >= foodTimeCycle){
          hasSprouted = false;
        }
      }
    }
    

}
//Player object class

public float timeSavedSinceStart = 0;

class Player{
  
  PVector pos, vel, zero, accel; //Pos to hold position on map and velocity to change the position accordingly
  float r; //Radius of the player's ellipse
  int savedTime;
  int totalTime = 3000;
  boolean timerStarting = false;
  int timerCount = 0;
  boolean showLine = true;
  PVector sightSize = new PVector(200, 200); // Stores the radius values for the ellipse representing the size of the sight radius
  boolean drawLine = false;
  float velLimit = 2;
  boolean canReproduce = false;
  boolean hasReproduced = false;
  float maxWidth = 45;
  float timeBeen;
  float timeAmountBig = 1000;
  float timeAmountFast = 2000;
  float timeSaved = 0;
  float timeStart;
  boolean tooOld = false;
  int totalEaten = 0;
  int eatenSince = 0;
  int fastOrBig;
  float factor = 0;
  boolean madePlayer = false;

  //Constructor holding the x and y co-ordinates of the player and its radius
  Player(float _x, float _y, float _r){
    
    pos = new PVector(_x, _y);; //Loading in new co-ordinates to variable pos. (PVectors hold 2D Vectors)
    vel = new PVector(0,0); //Initializing velocity to nothing for now (Center of screen)
    r = _r; //Setting radius to given radius
    zero = new PVector(0, 0);
    accel = new PVector(0, 0);
    savedTime = millis();
    timeSaved = millis();
    timeSavedSinceStart = millis();
    timeStart = millis();
    
    if(!madePlayer){
      fastOrBig = (int) random(1, 3);
    }

  }
    
    
  public void update(){
    
    int passedTime = millis() - savedTime;
    float dist = 1000;
    float nearestDist = 1000; //Stores nearest distance to food
    int nearestIndex = 0; //Stores index of the nearest food
    int index = 0;
    if(canStart == true){
      timeBeen = millis();
    }else{
      timeBeen = 0;
    }
    timeSavedSinceStart = timeBeen - timeStart;
    
      for (int i = foods.size()-1; i >=0; i--) {
        
        dist = sqrt(pow((pos.x - foods.get(i).x()), 2) + pow((pos.y - foods.get(i).y()), 2)); //Uses pythagoras to determine distance of all foods in arrayList.
        index = i;
        
        if(dist <= nearestDist){
          
          nearestDist = dist;
          nearestIndex = index;
          
        }
        
      }
      
      PVector target;
      
     if(countEaten < numFood){
       target = new PVector(foods.get(nearestIndex).x(), foods.get(nearestIndex).y());
       
       
     }else{
       target = PVector.random2D();
       showLine = false;
     }
     
    target.sub(pos);
    target.setMag(0.7f);
    
    //Determines if the food is inside the sight radius
    if(pow((foods.get(nearestIndex).x() - pos.x), 2) + pow((foods.get(nearestIndex).y() - pos.y), 2) < pow(sightSize.x/2, 2)){
      accel = target;
      drawLine = true;
    }else if(countEaten < numFood){
      accel = PVector.random2D();
      drawLine = false;
    }else{
      target = new PVector(0, 0);
      accel = target;
      target.sub(pos);
      target.setMag(0.7f);
    }
    
    
    
    vel.add(accel);
    pos.add(vel); //Changes the position variable (actual position changed by translating in Simulation class) of object every 60 frames according to the PVector which holds new co-ordinates

    if(fastOrBig == 1){
    
      if(r <= 15){
      
      velLimit = 4;
       
      }else if(r <= 20){
      
      velLimit = 3;
      
      }else if(r <= maxWidth){
    
      velLimit = 2;
      
      }
    }
    
    if(fastOrBig == 2){
      velLimit = 4 + factor;
    }
    
    if(madePlayer){
       velLimit = speed;
    }
    
     vel.limit(velLimit);
   
     if(showLine && drawLine){
       line(pos.x, pos.y, foods.get(nearestIndex).x(), foods.get(nearestIndex).y());
     }
     
     float d = PVector.dist(pos, foods.get(nearestIndex).pos); //distance between player and nearest food
     
     
     if(pos.x > width/2) {
      pos.x= width/2;
      vel.x = -vel.x;
    }
    if(pos.y > height/2) {
      pos.y = height/2;
      vel.y = -vel.y;
    }
    if(pos.x < -width/2) {
      pos.x = -width/2;
      vel.x = -vel.x;
    }
    if(pos.y < -height/2) {
      pos.y = -height/2;
      vel.y = -vel.y;
    }
    
    
    //This times every 3 seconds
    if(d <= 100){
      timerCount++;
      
      if(timerCount == 0){
        timerStarting = true;
      }else if(timerCount > 1){
        timerStarting = false;
      }
      
      if(timerStarting){
        savedTime = millis(); //Restarts the tiemr
      
        if(passedTime > totalTime){
          foods.remove(nearestIndex); //Removes the target food after 3 seconds of being close to it (To conteract the orbit it sometimes goes into)
          timerCount = 0;
        }
      }
      
    }
    

    if((r >= maxWidth - 4 && !madePlayer) && timeBeen >= 5000 || timeSavedSinceStart >= 15000 && timeBeen >= 5000){ //Can only reproduce if been alive for 15 seconds or reached adult sise
      canReproduce = true;
    }
    
    if(fastOrBig == 1 && timeBeen - timeSaved >= timeAmountBig && totalEaten >= 1){
      tooOld = true;
    }
    
    if(fastOrBig == 2 && timeBeen - timeSaved >= timeAmountFast && totalEaten >= 1){
      tooOld = true;
    }
    
    if(madePlayer && timeBeen - timeSaved >= timeAmountBig && totalEaten >= 3){
      tooOld = true;
    }
    
    if(madePlayer){
        sightSize.x = 500;
        sightSize.y = 500;
      }
    
    
   
  }


  public boolean eats(Foods other) {
    float d = PVector.dist(pos, other.pos); //Gets distance between the player and the food that comes in contact with it and stores it in 2D vector called d
    
    //if distance is smaller than the two radii added together, they are touching, so if they are touching then the food must be eaten.
    if (d < r + other.r || pow((other.x() - pos.x), 2) + pow((other.y() - pos.y), 2) < pow(1, 2)) {

      timeSaved = millis();
      totalEaten++;
      
      if(fastOrBig == 1){
        
              if(r <= maxWidth){
              r += 0.5f;
            }
      
            if(sightSize.x < 550 && sightSize.y < 550){
              sightSize.x += 10;
              sightSize.y += 10;
             }
        
      }
      
      if(fastOrBig == 2){ 
        
        if(velLimit <= 7){
           if(totalEaten >= 100){
             factor += 0.5f ;
           }else if(totalEaten >= 300){
             factor += 0.5f;
           }else if(totalEaten >= 700){
             factor += 0.5f;
           }else if(totalEaten >= 1300){
             factor += 1;
           }
        }
        
        if(sightSize.x < 350 && sightSize.y < 400){
              sightSize.x += 10;
              sightSize.y += 10;
             }
             
        if(r <= 20){
              r += 0.5f;
        }
        
      }
      
      
      countEaten++;
      return true;
    } else {
      return false;
    }
  }

  public void show() {
    stroke(255);

    if(fastOrBig == 1){
      fill(0, 128, 128);
    }else if(fastOrBig == 2){
      fill(255, 165, 0);
    }
    
    if(madePlayer){
      fill(colourR, colourG, colourB);
    }

    ellipse(pos.x, pos.y, r*2, r*2);
  }
  
  //Gets x co-ordinate of the player
  public float x(){
    float x_in;
    
    x_in = pos.x;
    
    return x_in;
  }
  
  //Gets y co-ordinate of the player
  public float y(){
    float y_in;
    
    y_in = pos.y;
    
    return y_in;
  }
  
}



boolean canStart = false;

Player player;

ArrayList<Foods> foods;
ArrayList<Player> players;
ArrayList<PVector> startPoses;
ArrayList<PVector> foodPoses;
int playerWidth = 12;
static int countEaten = 0;
float randDouble;
int rand;
int counter = 0;
int backgroundR = 255;
int backgroundG = 0;
int backgroundB = 0;
boolean makePlayer = false;
boolean showSpeed1 = false;
boolean showSpeed2 = false;
boolean showSpeed3 = true;
boolean showColour1 = false;
boolean showColour2 = true;
boolean showColour3 = false;
boolean showSize1 = true;
boolean showSize2 = false;
boolean showSize3 = false;
int speedValue = 3;
int colourValue = 2;
int sizeValue = 1;
float size;
float speed;
float colourR, colourG, colourB;
int countSize = 0;
boolean showHelpMenu;


public static int numPlayers = 6;
public static int numFood;


public void settings(){
  size(1700, 1000);
}

  
public void setup() {
  
  players = new ArrayList<Player>();
  startPoses = new ArrayList<PVector>();
  foodPoses = new ArrayList<PVector>();
  numFood = numPlayers * 100;

//Creating random starting positions for the players, on random sides of the screen.  
  for(int i = 0; i < numPlayers; i++){
      randDouble = random(1, 5); //Random number between 1 and 4, representing the 4 sides of the screen
      rand = (int) randDouble;
      
      if(rand == 1){
        startPoses.add(new PVector(-width/2, random(-height/2, height/2)));
      }else if(rand == 2){
        startPoses.add(new PVector(random(-width/2, width/2), height/2));
      }else if(rand == 3){
        startPoses.add(new PVector(width/2, random(-height/2, height/2)));
      }else{
        startPoses.add(new PVector(random(-width/2, width/2), -height/2));
      }
  }
  
  //Populating the array of starting positions
  for(int i = 0; i < numPlayers; i++){
    players.add(new Player(startPoses.get(i).x, startPoses.get(i).y, playerWidth)); //Populating the arena with players
  }
   
//Populatin the array with food.
  foods = new ArrayList<Foods>();
  
  for (int i = 0; i < numFood; i++) {
    float x = random(-width/2,width/2); //Radndom placement of foods
    float y = random(-height/2,height/2);
    foods.add(new Foods(x, y, 1)); //Instatiating each individual foods
    foodPoses.add(new PVector(x, y));
    
  }
  
  //Add an extra one so that there isn't an error when all the food is eaten. This food is out of the boundries and if there is one food left they go to the middle, not the food.
  foods.add(new Foods(-2000, -2000, 3)); //An extra food outside of the boundry to escape the index out of bounds exception when all the food is done.
  
}//end of setup


public void draw() {
  
  if(canStart){
    
    //---------------------------------------------TAKING IN THE VALUES FOR THE MADE PLAYER--------------------------------------------
    
    if(countSize == 0){
    
      if(sizeValue == 1){
      size = 15;
      }else if(sizeValue == 2){
      size = 30;
      }else if(sizeValue == 3){
      size = 60;
      }
    
      if(speedValue == 1){
        speed = 1.75f;
      }else if(speedValue == 2){
        speed = 3;
      }else if(speedValue == 3){
        speed = 6;
      }
      
      if(colourValue == 1){
        colourR = 218;
        colourG = 112;
        colourB = 214;
      }else if(colourValue == 2){
        colourR = 220;
        colourG = 20;
        colourB = 60;
      }else if(colourValue == 3){
        colourR = 60;
        colourG = 179;
        colourB = 113;
      }
    
      Player madePlayer = new Player(0, 0, size);
      madePlayer.madePlayer = true;
    
    //Make the "made" player
    
      players.add(madePlayer);
      numPlayers++;
    
    countSize++;
 } //End of if(countSize = 0)
    
  background(0);
  
  countEaten = 0;
   
  translate(width/2, height/2); //Initially, (0, 0) is set to the top left corner of the screen, so this sets it to the middle, well it at least makes 
  //translate(-player.pos.x, -player.pos.y); //Moves camera with player (some reason if it's positive it moves the opposite direction, so that's why it's negative)
  

  //Loops every frame to see what foods are eaten.
  for (int i = numFood; i >= 0; i--) {
    foods.get(i).show();
  }
  
  for(int i = 0; i < numFood - 1; i++){
    for(int j = 0; j < numPlayers; j++){
        if (players.get(j).eats(foods.get(i))){
          foods.remove(i); //Destroying food once eaten
          numFood--;
      }
    }
  }
  
  //------------------------------------------------REPRODUCTION OF PLAYERS--------------------------------------
  
    for(int i = 0; i < numPlayers; i++){
    if(players.get(i).canReproduce && !players.get(i).hasReproduced){
      players.get(i).hasReproduced = true;
      
      Player reproducedPlayer = new Player(0, 0, 90);
      
      if(players.get(i).madePlayer){
        
        reproducedPlayer = new Player(players.get(i).x(), players.get(i).y(), size);
        reproducedPlayer.madePlayer = true;
        
      }else{
        reproducedPlayer = new Player(players.get(i).x(), players.get(i).y(), 12);
      }
      
      players.add(reproducedPlayer); //Populating the arena with players
      players.get(players.size()-1).fastOrBig = players.get(i).fastOrBig;
      numPlayers++;
      
    }
    
    if(players.get(i).totalEaten - players.get(i).eatenSince >= 400){
      players.get(i).hasReproduced = false;
      players.get(i).eatenSince = players.get(i).totalEaten;
    }
    
  }
  
  
//updating each player each frame
for(int i = 0; i < numPlayers; i++){
  players.get(i).show();
  players.get(i).update();
}

for(int i = 0; i < numFood; i++){
  foods.get(i).update();
}

PVector distVector;

//Finding which player is bumping into which
for(int i = 0; i < numPlayers; i++){
  for(int j = 0; j < numPlayers; j++){
    
    float d = PVector.dist(players.get(i).pos, players.get(j).pos);
    
    
    if(d < players.get(i).r + players.get(j).r && players.get(i) != players.get(j)){
      distVector = new PVector((players.get(j).pos.x - players.get(i).pos.x)/2, (players.get(j).pos.y - players.get(i).pos.y)/2);
      players.get(j).pos = players.get(j).pos.add(distVector);
      players.get(j).vel.y = -players.get(j).vel.y;
      players.get(j).vel.x = -players.get(j).vel.x;
      
    }
  }
}

//If the player has not eaten in 2 seconds, it dies
for(int i = 0; i < numPlayers; i++){
  if(players.get(i).tooOld){
    players.remove(i);
    numPlayers--;
  }
}

//----------------------------------------------------The porduction of new food--------------------------------------------
for(int i = 0; i < numFood; i++){
  
  if(foods.get(i).canSprout && !foods.get(i).hasSprouted && numFood < 2000){
    
    int random = (int) random(1, 5);
    int radiusMin = 100;
    int radiusMax = 300;
    
    if(random == 1){
      
      float xPos = foods.get(i).x() + random(radiusMin, radiusMax);
      float yPos = foods.get(i).y() + random(radiusMin, radiusMax);
      
      if(xPos > -width/2 && xPos < width/2 && yPos > -height/2 && yPos < height/2){
        foods.add(new Foods(xPos, yPos, 1));
        numFood++;
        foods.get(i).tempTime = millis();
        foods.get(i).hasSprouted = true;
      }
      
    }else if(random == 2){
      
      float xPos = foods.get(i).x() - random(radiusMin, radiusMax);
      float yPos = foods.get(i).y() + random(radiusMin, radiusMax);
      
      if(xPos > -width/2 && xPos < width/2 && yPos > -height/2 && yPos < height/2){
        foods.add(new Foods(xPos, yPos, 1));
        numFood++;
        foods.get(i).tempTime = millis();
        foods.get(i).hasSprouted = true;
      }

    }else if(random == 3){
      
      float xPos = foods.get(i).x() + random(radiusMin, radiusMax);
      float yPos = foods.get(i).y() - random(radiusMin, radiusMax);
      
      if(xPos > -width/2 && xPos < width/2 && yPos > -height/2 && yPos < height/2){
        foods.add(new Foods(xPos, yPos, 1));
        numFood++;
        foods.get(i).tempTime = millis();
        foods.get(i).hasSprouted = true;
      }
      
    }else{
      
      float xPos = foods.get(i).x() - random(radiusMin, radiusMax);
      float yPos = foods.get(i).y() - random(radiusMin, radiusMax);
      
      if(xPos > -width/2 && xPos < width/2 && yPos > -height/2 && yPos < height/2){
        foods.add(new Foods(xPos, yPos, 1));
        numFood++;
        foods.get(i).tempTime = millis();
        foods.get(i).hasSprouted = true;
      }
    }

    
    
  }//End of if statment to see if food can sprout or not
}//End of production of new food for loop

//-----------------------------------------STOP BUTTON------------------------------------------------

     int stopX = -800;
     int stopY = -450;
     int stopWidth = 100;
     int stopHeight = 40;
      
     fill(255);

   if(mouseX - 850> stopX && mouseX - 850 < stopX + stopWidth && mouseY - 500 > stopY && mouseY - 500 < stopY + stopHeight){
     fill(152, 255, 152);
   }
 
   
   if(mousePressed && mouseX - 850 > stopX && mouseX - 850 < stopX + stopWidth && mouseY - 500 > stopY && mouseY - 500 < stopY + stopHeight){
     exit();
   }
   
   strokeWeight(2);
   rect(stopX, stopY, stopWidth, stopHeight, 20);
   
   fill(0);
   textSize(25);
   
   text("Stop", stopX + 22, stopY + 28);

  }else if(!canStart){
    
    if(!showHelpMenu){
    
    if(!makePlayer){
    
    if(backgroundG < 255 && backgroundR == 255 && backgroundB == 0){
          backgroundG++;
        }
        
        if(backgroundG == 255 && backgroundR > 0 && backgroundB == 0){
          backgroundR--;
        }
        
        if(backgroundG == 255 && backgroundR == 0 && backgroundB < 255){
          backgroundB++;
        }
        
        if(backgroundG > 0 && backgroundR == 0 && backgroundB == 255){
          backgroundG--;        
        }
        
        if(backgroundG == 0 && backgroundR == 0 && backgroundB > 0){
          backgroundB--;
        }
        
        if(backgroundG == 0 && backgroundR < 255 && backgroundB == 0){
          backgroundR++;
        }
        
    background(backgroundR, backgroundG, backgroundB);

   
   fill(255);
   stroke(160);
   strokeWeight(5);
   
   int beginX = 300;
   int beginY = 600;
   int beginWidth = 200;
   int beginHeight = 100;

   if(mouseX > beginX && mouseX < beginX + beginWidth && mouseY > beginY && mouseY < beginY + beginHeight){
     fill(139, 247, 253);
   }
   
   rect(beginX, beginY, beginWidth, beginHeight, 20);
   
   fill(255);
   int quitX = 750;
   int quitY = 600;
   int quitWidth = 200;
   int quitHeight = 100;

   if(mouseX > quitX && mouseX < quitX + quitWidth && mouseY > quitY && mouseY < quitY + quitHeight){
      fill(254, 216, 177);
   }
   
   rect(quitX, quitY, quitWidth, quitHeight, 20);
   
   fill(255);
   int makeX = 1200;
   int makeY = 600;
   int makeWidth = 200;
   int makeHeight = 100;

   if(mouseX > makeX && mouseX < makeX + makeWidth && mouseY > makeY && mouseY < makeY + makeHeight){
      fill(152, 255, 152);
   }
   
   rect(makeX, makeY, makeWidth, makeHeight, 20);
   
   fill(255);
   textSize(60);
   int textX = 600;
   int textY = 200;
   
   text("Welcome to the", textX, textY);
   text("Simulation of Natural Selection!", textX - 200, textY + 100);
   
   fill(0);
   textSize(30);
   
   text("BEGIN", beginX + 55, beginY + 60);
   
   fill(0);
   textSize(30);
   
   text("QUIT", quitX + 65, quitY + 60);
   
   fill(0);
   textSize(30);
   
   text("MAKE A", makeX + 42, makeY + 40);
   text("PLAYER", makeX + 50, makeY + 80);
    
    
   if(mousePressed && mouseX > beginX && mouseX < beginX + beginWidth && mouseY > beginY && mouseY < beginY + beginHeight){
     canStart = true;
   }else if(mousePressed && mouseX > quitX && mouseX < quitX + quitWidth && mouseY > quitY && mouseY < quitY + quitHeight){
     exit();
   }else if(mousePressed && mouseX > makeX && mouseX < makeX + makeWidth && mouseY > makeY && mouseY < makeY + makeHeight){
     makePlayer = true;
   }
 }// End of if(!makePlayer) 
  
   if(makePlayer){
      background(255, 152, 240);
      
      fill(255);
     textSize(60);
     int textX = 600;
     int textY = 200;
   
     text("Welcome to the", textX, textY);
     text("Player Designer!", textX, textY + 100);
     
     int backX = 75;
     int backY = 75;
     int backWidth = 100;
     int backHeight = 40;

   if(mouseX > backX && mouseX < backX + backWidth && mouseY > backY && mouseY < backY + backHeight){
     fill(152, 255, 152);
   }
   
   strokeWeight(2);
   rect(backX, backY, backWidth, backHeight, 20);
   
   fill(0);
   textSize(25);
   
   text("Back", backX + 25, backY + 30);
   
   if(mousePressed && mouseX > backX && mouseX < backX + backWidth && mouseY > backY && mouseY < backY + backHeight){
     fill(139, 247, 253);
     makePlayer = false;
   }
   
   //-------------------------------------------------Speed Buttons-------------------------------------------------------
   
   fill(255);
   textSize(50);
   text("Speed:", 100, 400);
   
   //-----------------------------------------------------------Speed Button 1---------------------------------------------------------
   
   int speed1X = 100;
   int speed1Y = 450;
   int speed1Width = 150;
   int speed1Height = 50;

   if(mousePressed && mouseX > speed1X && mouseX < speed1X + speed1Width && mouseY > speed1Y && mouseY < speed1Y + speed1Height){
     showSpeed1 = true;
     showSpeed2 = false;
     showSpeed3 = false;
   }

   fill(255);
   
   if(showSpeed1){
     fill(255, 0, 0);
     speedValue = 1;
   }
   
   rect(speed1X, speed1Y, speed1Width, speed1Height, 20);
   
   textSize(20);
   fill(0);
   text("Slow", speed1X + 50, speed1Y + 32);
   
   //-------------------------------------------------------Speed Button 2---------------------------------------------------------
   
   fill(255);
   int speed2X = 100;
   int speed2Y = 550;
   int speed2Width = 150;
   int speed2Height = 50;

   if(mousePressed && mouseX > speed2X && mouseX < speed2X + speed1Width && mouseY > speed2Y && mouseY < speed2Y + speed2Height){
     showSpeed1 = false;
     showSpeed2 = true;
     showSpeed3 = false;
   }
   
   if(showSpeed2){
     fill(255, 0, 0);
     speedValue = 2;
   }
   
   rect(speed2X, speed2Y, speed2Width, speed2Height, 20);
   
   textSize(20);
   fill(0);
   text("Medium", speed2X + 40, speed2Y + 32);
   
    //-------------------------------------------------------Speed Button 3---------------------------------------------------------
   
   fill(255);
   int speed3X = 100;
   int speed3Y = 650;
   int speed3Width = 150;
   int speed3Height = 50;

   if(mousePressed && mouseX > speed3X && mouseX < speed3X + speed3Width && mouseY > speed3Y && mouseY < speed3Y + speed3Height){
     showSpeed1 = false;
     showSpeed2 = false;
     showSpeed3 = true;
   }
   
   if(showSpeed3){
     fill(255, 0, 0);
     speedValue = 3;
   }
   
   rect(speed3X, speed3Y, speed3Width, speed3Height, 20);
   
   textSize(20);
   fill(0);
   text("Fast", speed3X + 53, speed3Y + 32);
   
   //--------------------------------------------------------------Colour Buttons---------------------------------------------------
   
   fill(255);
   textSize(50);
   text("Colour:", 740, 400);
   
   //-----------------------------------------------------------Colour Button 1---------------------------------------------------------
   
   int colour1X = 750;
   int colour1Y = 450;
   int colour1Width = 150;
   int colour1Height = 50;

   if(mousePressed && mouseX > colour1X && mouseX < colour1X + colour1Width && mouseY > colour1Y && mouseY < colour1Y + colour1Height){
     showColour1 = true;
     showColour2 = false;
     showColour3 = false;
   }

   fill(255);
   
   if(showColour1){
     fill(218, 112, 214);
     colourValue = 1;
   }
   
   rect(colour1X, colour1Y, colour1Width, colour1Height, 20);
   
   textSize(20);
   fill(0);
   text("Purple", colour1X + 45, colour1Y + 32);
   
   //-------------------------------------------------------Colour Button 2---------------------------------------------------------
   
   fill(255);
   int colour2X = 750;
   int colour2Y = 550;
   int colour2Width = 150;
   int colour2Height = 50;

   if(mousePressed && mouseX > colour2X && mouseX < colour2X + colour2Width && mouseY > colour2Y && mouseY < colour2Y + colour2Height){
     showColour1 = false;
     showColour2 = true;
     showColour3 = false;
   }
   
   if(showColour2){
     fill(220, 20, 60);
     colourValue = 2;
   }
   
   rect(colour2X, colour2Y, colour2Width, colour2Height, 20);
   
   textSize(20);
   fill(0);
   text("Red", colour2X + 55, colour2Y + 32);
   
    //-------------------------------------------------------Colour Button 3---------------------------------------------------------
   
   fill(255);
   int colour3X = 750;
   int colour3Y = 650;
   int colour3Width = 150;
   int colour3Height = 50;

   if(mousePressed && mouseX > colour3X && mouseX < colour3X + colour3Width && mouseY > colour3Y && mouseY < colour3Y + colour3Height){
     showColour1 = false;
     showColour2 = false;
     showColour3 = true;
   }
   
   if(showColour3){
     fill(60, 179, 113);
     colourValue = 3;
   }
   
   rect(colour3X, colour3Y, colour3Width, colour3Height, 20);
   
   textSize(20);
   fill(0);
   text("Green", colour3X + 48, colour3Y + 32);
   
    //--------------------------------------------------------------Size Buttons---------------------------------------------------
   
   fill(255);
   textSize(50);
   text("Size:", 1420, 400);
   
   //-----------------------------------------------------------Size Button 1---------------------------------------------------------
   
   int size1X = 1400;
   int size1Y = 450;
   int size1Width = 150;
   int size1Height = 50;

   if(mousePressed && mouseX > size1X && mouseX < size1X + size1Width && mouseY > size1Y && mouseY < size1Y + size1Height){
     showSize1 = true;
     showSize2 = false;
     showSize3 = false;
     
     sizeValue = 1;
   }

   fill(255);
   
   if(showSize1){
     fill(255, 0 , 0);
   }
   
   rect(size1X, size1Y, size1Width, size1Height, 20);
   
   textSize(20);
   fill(0);
   text("Small", size1X + 52, size1Y + 32);
   
   //-------------------------------------------------------Size Button 2---------------------------------------------------------
   
   fill(255);
   int size2X = 1400;
   int size2Y = 550;
   int size2Width = 150;
   int size2Height = 50;

   if(mousePressed && mouseX > size2X && mouseX < size2X + size2Width && mouseY > size2Y && mouseY < size2Y + size2Height){
     showSize1 = false;
     showSize2 = true;
     showSize3 = false;
     
     sizeValue = 2;
   }
   
   if(showSize2){
     fill(255, 0, 0);
   }
   
   rect(size2X, size2Y, size2Width, size2Height, 20);
   
   textSize(20);
   fill(0);
   text("Medium", size2X + 42, size2Y + 32);
   
    //-------------------------------------------------------Size Button 3---------------------------------------------------------
   
   fill(255);
   int size3X = 1400;
   int size3Y = 650;
   int size3Width = 150;
   int size3Height = 50;

   if(mousePressed && mouseX > size3X && mouseX < size3X + size3Width && mouseY > size3Y && mouseY < size3Y + size3Height){
     showSize1 = false;
     showSize2 = false;
     showSize3 = true;
     
     sizeValue = 3;
   }
   
   if(showSize3){
     fill(255, 0, 0);
   }
   
   rect(size3X, size3Y, size3Width, size3Height, 20);
   
   textSize(20);
   fill(0);
   text("Large", size3X + 48, size3Y + 32);
      
   }// End of makePlayer
   
      //-----------------------------------HELP BUTTON-------------------------------------------  

fill(255);
   int helpX = 1550;
   int helpY = 50;
   int helpWidth = 100;
   int helpHeight = 50;

   if(mousePressed && mouseX > helpX && mouseX < helpX + helpWidth && mouseY > helpY && mouseY < helpY + helpHeight){
     showHelpMenu = true;
   }
   
   if (mouseX > helpX && mouseX < helpX + helpWidth && mouseY > helpY && mouseY < helpY + helpHeight){
      fill(218, 112, 214);
   }
 
   rect(helpX, helpY, helpWidth, helpHeight, 20);
   
   textSize(17);
   fill(0);
   text("HELP", helpX + 30, helpY + 32);
   
  }//End of (!showHelpMenu)
   
   if(showHelpMenu){
     
     //-----------------------------------------------HELP MENU---------------------------------------------
     
     background(255, 203, 152);
     
     textSize(30);
     text("Help Menu:", 750, 100);
     text("This is a simulation , not a game!", 600, 150);
     text("The goal is to find the dominent species based on a set of skills. Each species has a certain adult size, top speed, colour and sight radius. The goal is to observe, throughout a series of random simulations which is the dominent species and consequently the most important characteristics in this environment. Players need to eat food in order to live on. After becoming an adult they are able to produce offspring of their own kind. Please make sure to design your own player! Your player will start in the middle of the screen, look out for it! DISCLAIMER: There is a bug that produces an IndexOutOfBoundsException. This bug does not happen very often, but when it does, this simulation can be dubbed inconclusive. I hope you do not encounter this and happy simulating!", 370, 200, 1000, 1000);
     
     int backX = 75;
     int backY = 10;
     int backWidth = 100;
     int backHeight = 40;
      
     fill(255);

   if(mouseX > backX && mouseX < backX + backWidth && mouseY > backY && mouseY < backY + backHeight){
     fill(152, 255, 152);
   }
   
   if(mousePressed && mouseX > backX && mouseX < backX + backWidth && mouseY > backY && mouseY < backY + backHeight){
     showHelpMenu = false;
   }
   
   strokeWeight(2);
   rect(backX, backY, backWidth, backHeight, 20);
   
   fill(0);
   textSize(25);
   
   text("Back", backX + 25, backY + 30);
     
   }//End of help menu
   
  }//End of if(canStart)
}//End of draw() functione
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "Food" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
